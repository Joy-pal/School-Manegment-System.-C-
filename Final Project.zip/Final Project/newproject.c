#include<stdio.h>
#include<conio.h>
void fornt()
{
                                       //this is the fornt page.

                         char dat[15],nam[100];
                        FILE *notic;
                        notic=fopen("sharenotic.txt","r");
                        while (fscanf(notic,"%s %s",dat ,nam)!=EOF)
                        {
                            printf("\t\t\t << Date %s >>\n",dat);
                            printf("\t\t................................\n");
                            printf("\t\t %s \n\n",nam);
                        }
                        fclose(notic);





                        printf("\n\t\t !.........................................\n");
                        printf("\t\t ! 1 :          << LIBRARY >>              '*.\n  ");
                        printf("\t\t ! 2 : << CHILDREEN PRACTICE  >>              *.\n");
                        printf("\t\t ! 3 : << ADDMISION  >>                         *.\n");
                        printf("\t\t ! 4 : << INFORMATION >>                       .*\n");
                        printf("\t\t ! 5 : << ADMIN PANEL >>                     .*\n");
                        printf("\t\t !..........................................*\n");
                        printf("\n\n\n \t\t\t\t<< PRESS ANY KEY TO ENTER >>\n\n\n");





}







void membership()
{
                        printf(" \t\t\t << Fill The Form Correctly >>\n");
                        printf("\t\t__________________________________________________________\n");

                        char  name[20];
                        char  number[20] ;
                        char c[10];
                        char  ID[10];

                        FILE*fp;
                        printf("\t\t_|____________________________________________________\n");
                        printf("\t\t_| enter your full name(don't pull a speech):      |\n");

                        printf("\t\t_| contact number:                                 |\n");
                        printf("\t\t_| class:                                          |\n");
                        printf("\t\t_| ID:                                             |\n");
                        printf("\t\t_|_________________________________________________|_\n\n");


                        printf("\t\t Enter Here ::::: \n");
                        scanf( "\t\t%s",&name);
                        scanf("%s",&number);
                        scanf("%s",&c);
                        scanf("%s",&ID);



                        printf("  you have been sucssesfully added.\n");


                        fp=fopen("membership.txt","a");
                        fprintf(fp,"\n%s\t%s\t%s\t%s\n",name,number,c,ID);




fclose(fp);



}

void admin()
                {



                           int test,PASSWORD,value;
                            int vip[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
                           printf("\t\t 1. << YOU NEED PASSWORD TO ENTER ADMIN PANEL  >>");
                           scanf("%d",&PASSWORD);

                           for(test=0;test<20;test++){
                           if (PASSWORD==vip[test]){
                            printf("_____________________________________________________________________________________________________________________\n");


                            printf("\t\t 1. <<       SHARE NOTICE .                  >>\n ");
                            printf("\t\t 2. <<       Update School Information  .    >>\n");
                            printf("\t\t 3. <<       UPDATE  INFORMATION .           >>\n");

                          /*  printf("\t\t 5: <<       inquary                         >>\n");
                            printf("\t\t 6: <<       Online Form FIllup              >> \n");*/

                            printf("_______________________________________________________________________________________________________________\n");
                            printf("ENTER VALUE HERE:");
                            scanf("%d",&value);
                            switch(value){

                            char date [15];

                            case 1:{

                            printf("\t\t << Share Notice >>\n");
                            printf("\t__________________________________________\n\n");
                            printf("\t\tEnter Date Please :::");
                            scanf("%s",&date);

                            char name [50];
                            printf("Share Notice :");
                            scanf("%s",name);
                            FILE *notic;
                            notic=fopen("sharenotic.txt","w");
                            fprintf(notic,"%s\t\t%s\n",date ,name);


                            printf("\n\n\n \t\t\t::::::::::::::: Thank You   :::::::::::::\n");
                            fclose(notic);


                                 break;
                                }//case 1.


                            case 3:
                                {
                                    printf("\t\t\t___________________________________________________________\n");
                                    printf("\t\t\t  |           Update Student                            |   \n");
                                    printf("\t\t\t..............................................................\n");
                                    printf("\t\t\t  |        1: Update Student Biography                  | .......    \n");
                                    printf("\t\t\t  |        2: Update Student Result                     | ....   \n");
                                    printf("\t\t\t__|_____________________________________________________|___\n");

                                    int enter ;
                                    printf("Enter Here :");
                                    scanf("%d",&enter);
                                    switch (enter)
                                    {
                                      case 1:{
                                          int loop;
                                          char sname[10],sroll[10],sbdate[15],sclass[20];

                                          printf("\t\t\t << Update Student Bios >>\n");
                                          printf("\t\t_________________________________________\n");
                                          FILE *sinfo;
                                          sinfo=fopen("student bios .txt","a");
                                          for(loop=0;loop<500;loop++)
                                          {

                                          printf("Student name :");
                                          scanf("%s",& sname);
                                          printf("student roll :");
                                          scanf("%s",&sroll);
                                          printf("Student birthdate:");
                                          scanf("%s",sbdate);
                                          printf("Class number :");
                                          scanf("%s",sclass);

                                          fprintf(sinfo,"\t%s\t%s\t%s\t%s\n",sname,sroll,sbdate,sclass);


                                          printf("\t\t........................................................\n");
                                          int brk;
                                          printf("Enter 0 to break ::: )");
                                          scanf("%d",&brk);
                                          if(brk==0)
                                            break;



                                          }
                                          fclose(sinfo);
                                          break;
                                             }// inner case 1;
                                      case 2:
                                        {
                                            char roll[15],subject[20],hmark[5],ymark[5];
                                            int loop;
                                            printf("\t\t\t << Update Result .>>\n");
                                            printf("\t\t...........................................\n");
                                            FILE *mark;
                                            mark=fopen("student_result.txt","a");
                                            for (loop=0;loop<500;loop++)
                                            {
                                            printf("\t\t\t << Student Roll::: ");
                                            scanf("%s",roll);
                                            printf("\t\t\t << Enter Subject ::");
                                            scanf("%s",subject);
                                            printf("\t\t\t << Marks Half Yearly :::");
                                            scanf("%s",hmark);
                                            printf("\t\t\t << Marks Yearly ::: ");
                                            scanf("%s",ymark);

                                            fprintf(mark,"\t%s\t%s\t%s\t%s\n",roll,subject,hmark,ymark);

                                            printf("\t\t\t << Enter 0 Not To Enter More >>");
                                            int brk;
                                            scanf("%d",&brk);
                                            if(brk==0)
                                                break;



                                            }// inner loop


                                        break;
                                        }// inner case 2.


                                    }// inner switch.

                                }//case 3.
                                      case 2:
                                        {
                                        printf("\t\t\t _____________________________________\n");
                                        printf("\t\t\t!   1 ::: Edit School Status          >>> \n");
                                        printf("\t\t\t!   2 ::: Edit Expenditure             >>>>\n");
                                        printf("\t\t\t!_____________________________________>>>\n\n");
                                        int ch;
                                        printf(" \t\t\t << Enter Choice >> ");
                                        scanf("%d",&ch);
                                        switch(ch)

                                        {
                                        case 1: {
                                                  printf("\t\t\t :: Edit School Status :: \n\n");
                                                   printf("\t\t\t ...................................................................  \n\n");
                                                  char info[1000],et[20],sa[20];

                                                  FILE *si;
                                                  si=fopen("school information.txt","a");
                                                  printf("\t\t\t   __________________________________________________________________________\n");
                                                  printf("\t\t\t           |                                                         |\n");
                                                  printf("\t\t\t           |     BANGLADESH NATIONAL PRIMAARY LEARNING SCHOOL        |\n");
                                                  printf("\t\t\t  ---------------------------------------------------------------------------\n\n\n ");

                                                  printf("Established Time::::");
                                                  scanf("%s",et);
                                                  printf("Student Amount :::");
                                                  scanf("%s",sa);
                                                  printf("Enter What Information You Want To Submite ::::::");
                                                  scanf("%s",info);
                                                  fprintf(si,"%s\t%s\t%s\n",et,sa,info);
                                                  fclose(si);




                                                  break;
                                                }// case 1
                                        case 2 :{
                                                  char eclass[10],Erfee[10],Etfee[10],efee[10];

                                                   printf("\t\t\t :: Edit Expenditure:: \n\n");

                                                  printf("\t\t\t :::  Enter class ::: \n");
                                                  scanf("%s",eclass);

                                                  printf("\t\t << REGITRATION FEES  >>\n");
                                                  scanf("%s",&Erfee);
                                                  printf("\t\t << TUTION FEES  ::  >>\n");
                                                  scanf("%s",&Etfee);
                                                  printf("\t\t  << else expenditure (monthly)   >>\n");
                                                  scanf("%s",efee);
                                                  FILE *ex;
                                                  ex=fopen("Expenditure.txt","a");
                                                  fprintf(ex,"%s\t%s\t%s\t%s\n",eclass,Erfee,Etfee,efee);
                                                  fclose(ex);




                                                  break;
                                                  }// case 2





                                        }// switch


                                        break;
                                        }
                          /*    case 5 :{




                              printf("\t\t\t\t <<inquary form>>\n");
                              printf("\t<< .............................................................>>\n\n");

                              FILE* inq;

                    inq=fopen("form.txt","a");
                    while( fscanf(inq,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s ", stu.dat, stu.snam, stu.gnam,stu.cla,stu.bran,stu.ad,stu.emal,stu.cel)!=EOF)
                    {


                    printf("\n\t\t\t\t<<DATE:%s>>",stu.dat);


                    printf(" <<Student's name:%s\n", stu.snam);

                    scanf("Father's name:%s\n", stu.gnam);

                    scanf("Expected class for addmision.:%s\n", stu.cla);

                    scanf("Expected brance :%s\n", stu.bran);

                    scanf("contact address:%s\n", stu.ad);

                    scanf("Email address :%s\n", stu.emal);

                    scanf("cell number:%s\n\n", stu.cel);

                    }



                    fclose(inq);
                                        }//case 5*/



                            }//switch
                           }//if loop
                           }//for loop.


                }// admine...

void information()
{
                    printf("\t\t\t\t\t\tInformation \n");
                    printf("\t\t\t ____________________________________________________________\n");
                    printf("\t\t\t                                                          \n");
                    printf("\t\t\t     1 :::::   {Student Result }                          \n ");
                    printf("\t\t\t     2 :::::   {Student Information }                     \n");
                    printf("\t\t\t     3 :::::   { About Expenditure }                      \n");
                    printf("\t\t\t     4 :::::   { School Information}                       \n  ");

                    printf("\t\t\t____________________________________________________________\n\n");

                    int choice;
                    printf("Enter Your Choice ::::  ");
                    scanf("%d",&choice);
                    switch (choice)
                    {
                    case 2:
                              {
                              char snam[10],srol[10],sbdat[15],sclas[10];
                              int res;
                              FILE *sinfo;

                              sinfo=fopen("student bios .txt","r");
                              while( fscanf(sinfo,"%s%s%s%s",snam,srol,sbdat,sclas)!=EOF)
                              {
                              char search[10];
                              printf("\t\t\t ::: Enter Roll Number ::::");
                              scanf("%s",search);
                              res=strcmp(srol,search);
                              if(res==0)
                              {
                              printf("\t\t\t # Your Name Is : %s\n",snam);
                              printf("\t\t\t # Your Roll Is : %s\n",srol);
                              printf("\t\t\t # Your Date Of Birth Is : %s\n",sbdat);
                              printf("\t\t\t # Your class  Is : %s\n",sclas);

                              break;
                              }

                              }
                              fclose(sinfo);

                              break;
                              }// case 2
                    case 1:
                              {
                              printf("\t\t\t << Student Result >>\n");
                              printf("\t\t.....................................\n\n");

                              char aroll[15],asubject[20],ahmarks[5],aymarks[5];
                              int res;
                              FILE *mark;
                              mark=fopen("student_result.txt","r");
                              char search[10],avg[5];

                              while( fscanf  (mark,"\t%s\t%s\t%s\t%s\n",aroll,asubject,ahmarks,aymarks)!=EOF)
                              {

                                        printf("%s\t%s\t%s\t",aroll,ahmarks,aymarks);


                              }
                              printf("\n");
                              printf("\t\t\t ::: Enter Roll Number ::::");
                              scanf("%s",search);
                              while( fscanf  (mark,"\t%s\t%s\t%s\t%s\n",aroll,asubject,ahmarks,aymarks)!=EOF)
                              {


                              res=strcmp(aroll,search);
                              if(res==0)
                              {


                              printf("\t\t\t<<   Roll         : %s >>\n",aroll);
                              printf("\t\t\t<<   Subject      : %s >>\n",asubject);


                              printf("\t\t\t<<   Half Yearly  : %s >>\n",ahmarks);
                              printf("\t\t\t<<   Yearly       : %s >>\n",aymarks);
                              printf("Enter Roll number Again To visit other Subject :::");

                              scanf("%s",search);






                              }


                             }
                             fclose(mark);



                        break;
                        }//case 1
                    case 3:{
                              char eclas[10],Efee[10],efee[10],efe[10];
                              printf("\t\t\t << Expenditure >>\n");
                              printf("\t\t____________________________________\n");
                              char ch[5];

                              int res;
                              printf("\t\t Enter Class ::");
                              scanf("%s",ch);
                              FILE *ex;
                              ex=fopen("Expenditure.txt","r");

                              while(fscanf(ex,"%s%s%s%s",&eclas,&Efee,&efee,&efe)!=EOF)
                              {

                                        res=strcmp(eclas, ch);
                                        if (res==0)
                                        {




                              printf("\t\t Expenditure Foe Class    %s\n",eclas);
                              printf("\t\t Registation Fee : %s\n",Efee);
                              printf("\t\t Tution Fee is %s\n",efee);
                              printf("\t\t Extra Expenditure is : %s\n",efe);


                                        }
                                        else
                                                  printf("\t\t\t :: Error ::");
                              }//while


                              break;
                              }
                    case 4:   {
                              char infor[1000],etime[20],samount[20];
                              FILE *si;
                              si=fopen("school information.txt","r");
                              printf("\t\t\t   __________________________________________________________________________\n");
                              printf("\t\t\t           |                                                         |\n");
                              printf("\t\t\t           |     BANGLADESH NATIONAL PRIMAARY LEARNING SCHOOL        |\n");
                              printf("\t\t\t  ---------------------------------------------------------------------------\n\n\n ");


                              while (fscanf(si,"%s%s%s",etime,samount,infor)!=EOF)
                              {

                                        printf("Established Time::::%s\n",etime);


                                        printf("Student Amount :::%s\n",samount);

                                        printf("Enter What Information You Want To Submite ::::::%s",infor);
                              }



                              fclose(si);

                              break;

                              }//school info..


                    }// switch



}//information
void library()
{
                      int vip[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};

                            printf(" \t\tLIBRARY INFORMATION \n\n");
                            printf("\t\t1 : << Append book  >>\n");
                            printf("\t\t2 : << LIBRARY MEMBERSHIP APPLYING  >>\n");
                            printf("\t\t3 : << Data Entry to LEND BOOK >>\n");
                            printf("\t\t4 : <<    LIBRARY BOOKS  >>\n");
                            int ch,i;
                            printf("\t\t Enter YOur Choich :::  ");
                            scanf("%d",&ch);
                            switch(ch)
                            {

                              case 1:{

                              char bname[20] , aname[20] ,bserial[10] ;
                              int pas,loop,brk;
                              printf("\t\t << Enter Password >>");
                              scanf("%d",&pas);

                              for (i=0;i<20;i++)
                              {



                              if (pas==vip[i])
                              {
                              printf(" << Append  Book >>\n\n");

                                    FILE *ab;
                                    ab = fopen("appendbook.txt","a");


                                    for(loop=0;loop>=0;loop++)
                                    {
                                        printf(" << enter book name >>>" );
                                        scanf("%s",&bname );
                                        printf(" << Enter Auture Name >> ");
                                        scanf("%s",&aname );
                                        printf("<< Enter book serial " );
                                        scanf("%s",&bserial );


                                        fprintf(ab,"%s\t %s \t    %s\n",bname , aname ,bserial  );

                                        int brk;
                                        printf("ENter 0 for Stop )");
                                        scanf("%d",&brk);
                                        if(brk==0)
                                        {
                                             break;

                                        }






                                     }//iner for
                                     fclose(ab);





                              }//iif password
                              }//for loop
                              break;
                              }//cas e1

                              case 2:
                            {
                               membership();
                              break;
                            }// case 2 memeber ship

                              case 3:

                              {
                              char  name [20],book[15],mobile  [12],serial [6];


                              char  ID [5];

                          FILE*lb;
                        lb=fopen("lendbook.txt","a");

                        int i,data;
                        printf("how many data you entered ::");
                        scanf("%d",&data);
                        for (i=0;i>=0;i++)
                        {
                            printf("enter  student  name(don't pull a speech):");
                            scanf("%s",&name);

                            printf("Student ID:");
                            scanf("%s",&ID);

                            printf("enter  Book  name(don't pull a speech):");
                            scanf("%s",&book);

                            printf("enter  book serial (don't pull a speech):");
                            scanf("%s",&serial);

                            printf("enter  DATE (don't pull a speech):");
                            scanf("%s",&mobile);

                            fprintf(lb,"%s\t%s\t%s\t%s\t%s\n",name,ID,book,serial,mobile);

                            int brk;
                            printf("Press 0 to break the loop ");
                            scanf("%d",&brk);
                            if(brk==0)
                                break;


                        }








                        printf(" \t\t you have been sucssesfully added.\n\t\t you can brow book\n");





                        fclose(lb);
                        break;


                              break;
                              }//lend book

                              case 4:
                               {
                              char bnam[20] , anam[20] ,bseril[10] ;

                              printf(" \t\t\t<< Visit  Book >>\n\n");

                              FILE *ab;

                              ab = fopen("appendbook.txt","r");
                              while( fscanf(ab,"%s %s  %s   ",&bnam ,& anam ,&bseril  )!=EOF)
                              {
                              printf("Book Name Is %s\t",bnam);
                              printf("Book's Autor Name Is %s\t",anam);
                              printf("Book Serial IS %s\n",bseril);
                              }
                              fclose(ab);




                               } //case 4







                            }//switch






}// library


void addmision()// THIS FUNCTION IS USED TO INDICATE ADDMISION.
                    {
                            int value;

                            struct mision// structure .
                    {
                            char date[10],day[10],month[10],year[5],sname[15],gname[15],clas[10],branc[20],email[20],cell[100],add[50];
                    }       stu;

                            printf("\t\t\t\t  << ADDMISION  >>\n");

                            printf("\t\t\t\t  << 1. ADDMISION  >>\n");

                            printf("\t\t\t\t <<  2. inquary form>>\n");

                            printf("\t\t\t\t  << ENTER YOUR CHOICE >> ");


                           scanf("%d",&value);
                           switch(value)
                           {

                            case 1:{

                            printf("\t\t\t\t  << @.  ADDMISION  >>\n\n");

                            FILE* jp;



                            printf("\t<<ADDMISION FORM (ONLINE) :>>\n\n");
                            printf("\n\t\t\t\t<<DATE of SUBBITION THE FORM*:>>");
                            printf("\t<<day:>>");
                            scanf("%s",&stu.day);
                            printf("\t\t\t\t\t\t\t\t\t<<month:>>");
                            scanf("%s",&stu.month);



                            printf("\n\t\t\t\t <<Student's name*:>>");
                            scanf("%s",&stu.sname);
                            printf("\n\t\t\t\t <<Father's name*:>>");
                            scanf("%s",&stu.gname);
                            printf("\n\t\t\t\t <<Expected class for addmision.*:>>");
                            scanf("%s",&stu.clas);
                            printf("\n\t\t\t\t <<Expected brance* :>>");
                            scanf("%s",&stu.branc);
                            printf("\n\t\t\t\t <<contact address:>>");
                            scanf("%s",&stu.add);
                            printf("\n\t\t\t\t <<Email address :.>>");
                            scanf("%s",&stu.email);
                            printf("\n\t\t\t\t <<cell number*:>>");
                            scanf("%s",&stu.cell);
                            printf("\t\t\t\t<<<<<<<YOUR WORK IS SUCCESFULLY DONE>>>>>>>");
                            printf("\n\t<<PLEASE MEET WITH ADDMISION DEPARTMENT WITHIN THE 7 DATE WITH ALL REQUIRMENTS GIVEN BELOW:>>\n\n");



                            jp=fopen("addmit.txt","a");
                            fprintf(jp,"\t%s%s%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n\n", stu.day,stu.month,stu.year, stu.sname, stu.gname,stu.clas,stu.branc,stu.add,stu.email,stu.cell);

                            fclose(jp);
                            printf("\t\t\t\t<<<<<<< #S.S.C & H.S.C. certificate .\n\t\t\t 2 photo(pp)>>>>>>>");

                            break;
                                        }// cas e  1.....


        case 2:{
                            printf("\t\t\t\t <<inquary form>>\n");
                            printf("\t<< .............................................................>>\n\n");

                            FILE* inq;

                            printf("\t<<COMMENT HERE :>>\n\n");
                            printf("\n\t\t\t\t<<DATE:>>");
                            scanf("%s",&stu.date);
                            printf("\n\t\t\t\t <<  name:>>");
                            scanf("%s",&stu.sname);

                            printf("\n\t\t\t\t <<inqury topic:>>");
                            scanf("%s",&stu.clas);


                            printf("\n\t\t\t\t <<Email address :.>>");
                            scanf("%s",&stu.email);
                            printf("\n\t\t\t\t <<enter YOUR COMMENT ::::>>");
                            scanf("%s",&stu.cell);
                            printf("\t\t\t\t<<<<<<<YOUR WORK IS SUCCESFULLY DONE>>>>>>>");


                           inq=fopen("form.txt","a");
                    fprintf(inq,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n\n\n", stu.date, stu.sname ,stu.clas  ,stu.email,stu.cell);

                            fclose(inq);
                            break;
                 }// case 2....
           }

}///admission



void letter()//this is for game functon.
{


                                             char letter  ;
                                             printf("\t\t \t\t<< Enter Alphabet In Small Letter .>>");
                                             scanf(" %c",&letter);
                                             if (letter=='a')
                                                  {
                                             printf("This is A. THE FIRST ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<APPLE>>");


                                                    }
                                             else if(letter=='b'){
                                             printf("This is B .\n THE SECOND ALPHABET IN ENGLISH LANGUAGE.\n");
                                             printf("THIS STANDS FOR <<BALL>>\n");

                                                                }
                                             else if(letter=='c'){
                                             printf("This is C. THE THIRED ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<CAT>>");

                                                                }
                                             else if(letter=='d'){
                                             printf("This is D. THE FORTH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<DOG>>");

                                                                }
                                             else if(letter=='e'){
                                             printf("This is E. THE FIFTH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<EYE>>");

                                                                }
                                             else if(letter=='f'){
                                             printf("This is F. THE 6TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<FOOD>>");

                                                                }
                                             else if(letter=='g'){
                                             printf("This is G. THE 7NTH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<GOD>>");

                                                                }
                                             else if(letter=='h'){
                                             printf("This is H. THE 8TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<HEN>>");

                                                                    }
                                             else if(letter=='i'){
                                             printf("This is I. THE 9TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<IRON>>");

                                                                }
                                     else if(letter=='j'){
                                             printf("This is  J. THE 10TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<JOY>>");

                                    }
                                     else if(letter=='k'){
                                             printf("This is K. THE 11TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<KOOK>>");

                                    }
                                     else if(letter=='l'){
                                             printf("This is L. THE 12TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<LIGHT>>");

                                    }
                                     else if(letter=='m'){
                                             printf("This is M. THE 13TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<MONTH>>");

                                    }
                                     else if(letter=='n'){
                                             printf("This is N. THE 14TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<NOVEMBER>>");

                                    }
                                     else if(letter=='o'){
                                             printf("This is O. THE 15TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<ORANGE>>");

                                    }
                                     else if(letter=='p'){
                                             printf("This is P. THE 16TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<PIPE>>");

                                    }
                                     else if(letter=='q'){
                                             printf("This is Q. THE 17TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<QUEEN>>");

                                    }
                                     else if(letter=='r'){
                                             printf("This is R. THE 18TH  ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<ROBOT>>");

                                    }
                                     else if(letter=='s'){
                                             printf("This is S. THE 19TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<STUDENT>>");

                                    }
                                     else if(letter=='t'){
                                             printf("This is T. THE 20TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<TOOTH>>");

                                    }
                                     else if(letter=='u'){
                                             printf("This is U. THE 21ST ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<UMBRELLA>>");

                                    }
                                     else if(letter=='v'){
                                             printf("This is V. THE 22ND ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<VOWEL>>");

                                    }
                                     else if(letter=='w'){
                                             printf("This is W. THE 23RD ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<WINDOW>>");

                                    }
                                     else if(letter=='x'){
                                             printf("This is X. THE 24TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<X-RAY>>");

                                    }
                                     else if(letter=='y'){
                                             printf("This is Y. THE 25TH ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<YELLOW>>");

                                    }
                                     else if(letter=='z'){
                                             printf("This is Z. THE LAST OR 26TH  ALPHABET IN ENGLISH LANGUAGE.");
                                             printf("THIS STANDS FOR <<ZERO>>");

                                    }



}




void game()//playing with childreen.
{
                            printf("\n\n\t\t\t\t\t[[ FUN WITH CHILDREEN ]]\n\n\n");
                            printf("\t\t\t;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;");
                            printf("\n\n\n");

                            printf("\t\t\t\t\t(( ENTER 1: FOR NAMTA. ))\n ");
                            printf("\t\t\t\t\t(( ENTER 2: CALCULATOR. ))\n ");
                            printf("\t\t\t\t\t(( ENTER 3: ALPHABETS. ))\n ");
                            printf("\t\t\t;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n\n");
                            int value;
                            printf("\t\t\t\t\t<<ENTER VALUE>>");
                            printf("\n\t\t\t.............................................................\n");
                            scanf("%d",&value);


                            switch (value)
                            {




                        case 1: {
                            printf("\n\t\t\t <<NAMTA FROM 1-10.>>\n");
                            printf("\t\t\t.............................................................\n");

                            int enter;

                            printf("\t\t\t{{ ENTER WHICH CASE OF NAMTA YOU WANT: }} ");
                            scanf("%d",&enter);
                            if(enter<11){
                            int i=1;
                            printf("\t\t\t.............................................................\n");
                            printf("\t\tTHE NAMTA OF CASE %d\n\n",enter);
                            printf(".............................................................\n");
                            while(i<11){

                            printf("\t\t%d * %d =  %d\n",enter,i,enter*i);
                            i++;
                                      }
                            printf("..............................................................");
                                        }

                            break;
                            }





                    case 2: {
                                printf("\t\t\t\t\t <<CALCULATOR.>>\n");
                                printf("\t\t\t.............................................................\n");


                                int x=1,value;
                                printf("\t\t\t\t\t <<ENTER WHICH THING YOU WANT TO WORK WITH .>>\n");
                                printf("\t\t\t.............................................................\n");



                                printf("\t\t\t\t\t <<ENTER 1 FOR ADDING  .>>\n");
                                printf("\t\t\t\t\t <<ENTER 2 FOR SUBSTRUCTION .>>\n");
                                printf("\t\t\t\t\t <<ENTER 3 FOR  MULTIPLICATION.>>\n");
                                printf("\t\t\t\t\t <<ENTER 4 FOR DIVIDATION .>>\n");
                                printf("\t\t\t.............................................................\n");

                                scanf("%d",&value);
                                switch (value)
                                {
                                case 1: {
                                                while(x==1){
                                                int i,n;
                                                float  element;
                                                float sum=0;
                                                printf("\t\t\t\t\t <<HOW MANT ELEMENTS YOU WANT TO ADD.>>");
                                                scanf("%d",&n);

                                                for (i=1;i<=n;i++){
                                                printf("\t\t\t\t\t <<ENTER ELEMENT %d >>",i);
                                                scanf("%f",&element);
                                                sum=sum+element;
                                                                }
                                                printf("\t\t\t.............................................................\n");
                                                printf("\t\t\t\t\t <<THE ADDITION OF THE ELEMENTS IS %f>>",sum);

                                                printf("\nENTER 1 TO CONTINUE ADDING  :");
                                                scanf("%d",&x);




                                                }
                                                 break;
                                        }

                                case 2: {
                                                while(x==1){
                                                int i,n;
                                                float  element;
                                                float sum=0;
                                                printf("\t\t\t\t\t <<HOW MANY ELEMENTS YOU WANT TO SUBSTRACT .>>");
                                                scanf("%d",&n);

                                                for (i=1;i<=n;i++){
                                                printf("\t\t\t\t\t <<ENTER ELEMENT %d >>",i);
                                                scanf("%f",&element);
                                                sum=sum-element;
                                                                }
                                                printf("\t\t\t.............................................................\n");
                                                printf("\t\t\t\t\t <<THE SUBSTRUCTION OF THE ELEMENTS IS %f>>",sum);

                                                break;
                                                printf("\nENTER 1 TO CONTINUE SUBSCRIPTING :");
                                                scanf("%d",&x);
                                                }

                                            }

                                case 3: {
                                                while(x==1){
                                                int i,n;
                                                float  element;
                                                float sum=1;
                                                printf("\t\t\t\t\t <<HOW MANT ELEMENTS YOU WANT TO multiple .>>");
                                                scanf("%d",&n);

                                                for (i=1;i<=n;i++)  {
                                                printf("\t\t\t\t\t <<ENTER ELEMENT %d >>",i);
                                                scanf("%f",&element);
                                                sum=sum*element;
                                                                    }
                                                printf("\t\t\t.............................................................\n");
                                                printf("\t\t\t\t\t <<THE MULTIPLICATION OF THE ELEMENTS IS %f>>",sum);

                                                break;
                                                printf("\nENTER 1 TO CONTINUE MULTIPLING :");
                                                scanf("%d",&x);

                                                            }//for while loop comparing x==1;
                                                break;
                                        }// case 3.
                                        case 4: {
                                                while(x==1){
                                                float n;
                                                float  element;
                                                float sum ;
                                                printf("\t\t\t\t\t <<enter the first element : >>" );
                                                scanf("%f",&element);
                                                printf("\t\t\t\t\t <<enter the second element : >>" );
                                                scanf("%f",&n);
                                                sum= element/n;




                                                printf("\t\t\t.............................................................\n");
                                                printf("\t\t\t\t\t <<THE devidetion OF THE ELEMENTS IS %f>>\n",sum);



                                                printf("\nENTER 1 TO CONTINUE DEVIDING :\n");
                                                scanf("%d",&x);

                                                                }
                                                break;
                                            }//case 4.
                                                default :{
                                                              printf("\t\t\t\t\t <<SYNTEX ERROR : >>" );
                                                  }
                                 }//switch case.


                                                break;
                            }// case 2

                     case 3:
                         {

                                char alphabet[4][8]={'a','b','c','d','e','f','g','h','i','j','k','l', 'm','n','o','p','q','r','s','t','u','v','w','x','y','z'  };
                                char capital[4][8]={'A','B','C','D','E','F','G','H','I','J','K','L', 'M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'  };
                                int i,j;

                                printf("\t\t \t\t<<ALPHABETS.>>\n\n");
                                printf("\t\t\t.............................................................\n");
                                printf("\t\t \t\t<<ALPHABETS IN SMALL LETTER .>>\n\n");
                                printf("\t\t\t.............................................................\n");

                                for(i=0;i<4;i++){
                                for(j=0;j<8;j++){
                                printf("    %c    ",alphabet[i][j]);
                                            }
                                printf("\n");
                                            }
                                printf("\t\t\t.............................................................\n");

                                printf("\t\t \t\t<<ALPHABETS IN capital LETTER .>>\n\n");
                                printf("\t\t\t.............................................................\n");


                                for(i=0;i<4;i++){
                                for(j=0;j<8;j++){
                                printf("    %c    ",capital[i][j]);
                                                }
                                printf("\n");
                                                }
                                printf("\t\t\t.............................................................\n");


                                int swit ;

                                printf("\t\t \t\t<< Enter 1 for checking vowel .>>\n\n");
                                printf("\t\t \t\t<< Enter 2 for checking (what does it stand for ).>>\n\n");
                                printf("\t\t\t.............................................................\n");
                                scanf("%d",&swit);

                                switch(swit) {
                                case 1:  {

                                        printf("Enter THe Alphabet ::\n ");
                                        char ch;
                                        scanf(" %c",&ch);
                                       if (ch == 'a' ){
                                        printf("\t\t<< %c Is vowel >>\n",ch);
                                       }
                                       else if (  ch=='e' ){
                                        printf("\t\t<< %c Is vowel >>\n",ch);
                                       }
                                      else if (  ch=='i' ){
                                        printf("\t\t<< %c Is vowel >>\n",ch);
                                       }
                                       else  if (  ch=='o' ){
                                        printf("\t\t<< %c Is vowel >>\n",ch);
                                       }
                                     else  if ( ch||'u'){
                                        printf("\t\t<< %c Is vowel >>\n",ch);
                                       }
                                       else
                                       {
                                                 printf(" %c is Consonant >>>>\n",ch);
                                       }


                                break;
                                    }


                                case 2:
                              {
                                letter();
                              break;
                              }//cae 2
                                    }// inner switch

                                break;

                                    }//case 3;


                                default : {
                                printf("\t\t << START FROM BEGGINING .>>");

                                break;                                   }
                                }

                                }//game








int main ()
{






                                    int value1,key=1,continue1=0,vip;

                                     printf("\n\n\n");
                                     printf("\t\t\t   ___________________________________________________________________\n");
                                     printf("\t\t\t           |              |      |          |                  |\n");
                                     printf("\t\t\t           |    WECOME    |  TO  | SCHOOL   |  SMARTALITION    |\n");
                                     printf("\t\t\t  --------------------------------------------------------------------\n\n\n\n\n\n");





                                    while(continue1==0){
                                    fornt();
                                    printf("\t\t\t\t<< ENTER NO HERE: >> ");
                                    scanf("%d",&continue1);

                                    switch (continue1){

                                    case 1:
                                    {
                                    int continue1=1;
                                    while(continue1==1){
                                     library();
                                    printf("ENTER 1 TO CONTINUE.");
                                    scanf("%d",&continue1);
                                    }//whle
                                    break;

                                    }//case 1

                             case 2:{

                                int continue1=1;
                                while(continue1==1){
                                game();
                                printf("ENTER 1 TO CONTINUE.");
                                scanf("%d",&continue1);
                                }

                                break;
                                    }
                              case 3: {
                                int continue1=1;
                                while(continue1==1){
                                addmision();
                                printf("ENTER 1 TO CONTINUE.");
                                scanf("%d",&continue1);
                                }
                                break;
                                    }

                            case 4:{

                                int continue1=1;
                                while(continue1==1){
                                information();
                                printf("ENTER 1 TO CONTINUE.");
                                scanf("%d",&continue1);
                                }
                                break;
                                    }
                            case 5:{

                                 int continue1=1;
                                while(continue1==1){
                                admin();
                                printf("ENTER 1 TO CONTINUE.");
                                scanf("%d",&continue1);
                                }
                                  break;

                                    }


                    getch();
                    }//switch
                    printf("enter 0 for home page");
                    scanf("%d",&continue1);

                    }// while
                    printf("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
                    printf("\t\t\t\tSORRY, UNITERUPTED SERVICE .\n\n\n");
return 0;

}

